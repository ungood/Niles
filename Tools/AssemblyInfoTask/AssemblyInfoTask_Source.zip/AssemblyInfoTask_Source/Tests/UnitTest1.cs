using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Build.Tasks;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using NMock;
using NMock.Constraints;
using System.IO;

namespace Tests
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class AssemblyInfoTests
    {
        DynamicMock engineMock;
        AssemblyInfo task;

        #region Setup
        [TestInitialize]
        public void TestInitialize()
        {
            // We always want to start with an AssemblyInfo.cs file that's in its basic state.
            File.Copy(@"AssemblyInfo.cs.original", @"AssemblyInfo.cs", true);
            File.Copy(@"AssemblyInfo.vb.original", @"AssemblyInfo.vb", true);
            File.Copy(@"AssemblyInfo_NoVersions.cs.original", @"AssemblyInfo_NoVersions.cs", true);

            // The engine mock is re-created before each test run to clear out any expectations that might have been
            // set by tests.
            this.engineMock = new DynamicMock(typeof(Microsoft.Build.Framework.IBuildEngine));
            this.task = new AssemblyInfo();
            this.task.BuildEngine = (Microsoft.Build.Framework.IBuildEngine)this.engineMock.MockInstance;

            ITaskItem i = new TaskItem();
            this.task.AssemblyInfoFile = new ITaskItem[] { i };
        }
        #endregion


        #region Direct Set Tests
        [TestMethod]
        public void NoVersionInFile()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo_NoVersions.cs";

            // This test case needs some special validation by the mock, so we'll set up the mock appropriately
            // then replace the build engine provided by Init() on the task object.
            this.engineMock.Expect("LogErrorEvent", new IsAnything());
            this.engineMock.ExpectAndReturn("ContinueOnError", true, null);
            this.task.BuildEngine = (Microsoft.Build.Framework.IBuildEngine)this.engineMock.MockInstance;

            this.task.AssemblyMajorVersion = "1";

            this.task.Execute();
            this.engineMock.Verify();
        }

        [TestMethod]
        public void DirectSetCSharp()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.cs";

            this.DirectSetTest(this.task);
        }

        [TestMethod]
        public void DirectSetVb()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.vb";

            this.DirectSetTest(this.task);
        }

        private void DirectSetTest(AssemblyInfo task)
        {
            task.AssemblyMajorVersion = "2";
            task.AssemblyMinorVersion = "3";
            task.AssemblyBuildNumber = "4";
            task.AssemblyRevision = "5";
            task.AssemblyBuildNumberType = "NoIncrement";
            task.AssemblyRevisionType = "NoIncrement";

            task.AssemblyFileMajorVersion = "2";
            task.AssemblyFileMinorVersion = "3";
            task.AssemblyFileBuildNumber = "4";
            task.AssemblyFileRevision = "5";
            task.AssemblyFileBuildNumberType = "NoIncrement";
            task.AssemblyFileRevisionType = "NoIncrement";

            task.Execute();

            // Now validate that it worked by reading in the AssemblyInfo file
            AssemblyInfoWrapper wrapper = new AssemblyInfoWrapper(task.AssemblyInfoFile[0].ItemSpec);
            Microsoft.Build.Tasks.Version version;

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            Assert.AreEqual("2", version.MajorVersion, "The AssemblyMajorVersion direct set failed");
            Assert.AreEqual("3", version.MinorVersion, "The AssemblyMinorVersion direct set failed");
            Assert.AreEqual("4", version.BuildNumber, "The AssemblyBuildNumber direct set failed");
            Assert.AreEqual("5", version.Revision, "The AssemblyRevision direct set failed");

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            Assert.AreEqual("2", version.MajorVersion, "The AssemblyFileMajorVersion direct set failed");
            Assert.AreEqual("3", version.MinorVersion, "The AssemblyFileMinorVersion direct set failed");
            Assert.AreEqual("4", version.BuildNumber, "The AssemblyFileBuildNumber direct set failed");
            Assert.AreEqual("5", version.Revision, "The AssemblyFileRevision direct set failed");
        }
        #endregion

        #region DateTime Tests
        [TestMethod]
        public void DateTimeCSharp()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.cs";
            this.DateTimeTest(this.task);
        }

        [TestMethod]
        public void DateTimeVb()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.vb";
            this.DateTimeTest(this.task);
        }

        private void DateTimeTest(AssemblyInfo task)
        {
            task.AssemblyBuildNumberType = "DateString";
            task.AssemblyBuildNumberFormat = "yyMMdd";

            task.AssemblyRevisionType = "DateString";
            task.AssemblyRevisionFormat = "yyMMdd";

            task.AssemblyFileBuildNumberType = "DateString";
            task.AssemblyFileBuildNumberFormat = "yyMMdd";

            task.AssemblyFileRevisionType = "DateString";
            task.AssemblyFileRevisionFormat = "yyMMdd";

            task.Execute();

            // Now validate that it worked by reading in the AssemblyInfo file
            AssemblyInfoWrapper wrapper = new AssemblyInfoWrapper(task.AssemblyInfoFile[0].ItemSpec);
            Microsoft.Build.Tasks.Version version;

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyBuildNumberFormat), version.BuildNumber, "The AssemblyBuildNumber DateTime formatting failed");
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyRevisionFormat), version.Revision, "The AssemblyBuildNumber DateTime formatting failed");

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyFileBuildNumberFormat), version.BuildNumber, "The AssemblyFileBuildNumber DateTime formatting failed");
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyFileRevisionFormat), version.Revision, "The AssemblyFileBuildNumber DateTime formatting failed");

        }
        #endregion

        #region AutoIncrement Tests
        [TestMethod]
        public void AutoIncrementCSharp()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.cs";
            this.AutoIncrementTest(this.task);
        }

        [TestMethod]
        public void AutoIncrementVb()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.vb";
            this.AutoIncrementTest(this.task);
        }

        private void AutoIncrementTest(AssemblyInfo task)
        {
            task.AssemblyBuildNumberType = "AutoIncrement";
            task.AssemblyRevisionType = "AutoIncrement";

            task.AssemblyFileBuildNumberType = "AutoIncrement";
            task.AssemblyFileRevisionType = "AutoIncrement";

            task.Execute();

            // Now validate that it worked by reading in the AssemblyInfo file
            AssemblyInfoWrapper wrapper = new AssemblyInfoWrapper(task.AssemblyInfoFile[0].ItemSpec);
            Microsoft.Build.Tasks.Version version;

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            Assert.AreEqual("1", version.BuildNumber, "The AssemblyBuildNumber auto-increment failed");
            Assert.AreEqual("1", version.Revision, "The AssemblyRevision auto-increment failed");

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            Assert.AreEqual("1", version.BuildNumber, "The AssemblyFileBuildNumber auto-increment failed");
            Assert.AreEqual("1", version.Revision, "The AssemblyFileRevision auto-increment failed");
        }

        /// <summary>
        /// This test validates that the revision build number resets to zero when incremented across a day.
        /// It simulates building twice on one day, then once on the next.
        /// </summary>
        [TestMethod]
        public void AutoIncrementAcrossDayCSharp()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.cs";
            this.AutoIncrementAcrossDayTest(this.task);
        }

        /// <summary>
        /// This test validates that the revision build number resets to zero when incremented across a day.
        /// It simulates building twice on one day, then once on the next.
        /// </summary>
        [TestMethod]
        public void AutoIncrementAcrossDayVb()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.vb";
            this.AutoIncrementAcrossDayTest(this.task);
        }

        private void AutoIncrementAcrossDayTest(AssemblyInfo task)
        {
            AssemblyInfoWrapper wrapper;
            Microsoft.Build.Tasks.Version version;

            task.AssemblyBuildNumberType = "DateString";
            task.AssemblyBuildNumberFormat = "yyMMdd";
            task.AssemblyRevisionType = "AutoIncrement";

            task.AssemblyFileBuildNumberType = "DateString";
            task.AssemblyFileBuildNumberFormat = "yyMMdd";
            task.AssemblyFileRevisionType = "AutoIncrement";

            // Run two "builds"
            task.Execute();
            task.Execute();

            // At this point the date string should be today's date, and the revision should be 1.
            wrapper = new AssemblyInfoWrapper(task.AssemblyInfoFile[0].ItemSpec);

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyBuildNumberFormat), version.BuildNumber, "The AssemblyBuildNumber auto-increment failed");
            Assert.AreEqual("1", version.Revision, "The AssemblyRevision auto-increment failed");

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyFileBuildNumberFormat), version.BuildNumber, "The AssemblyFileBuildNumber auto-increment failed");
            Assert.AreEqual("1", version.Revision, "The AssemblyFileRevision auto-increment failed");

            // Now we have to hack the AsssemblyInfo file to make it look like the last build was yesterday.
            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            version.BuildNumber = DateTime.Now.Subtract(new TimeSpan(1, 0, 0, 0, 0)).ToString(task.AssemblyBuildNumberFormat);
            wrapper["AssemblyVersion"] = version.ToString();

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            version.BuildNumber = DateTime.Now.Subtract(new TimeSpan(1, 0, 0, 0, 0)).ToString(task.AssemblyFileBuildNumberFormat);
            wrapper["AssemblyFileVersion"] = version.ToString();

            // Save the hacked AssemblyInfo file back out
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter(task.AssemblyInfoFile[0].ItemSpec);
                wrapper.Write(writer);
                writer.Close();
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }

            // Now run the task again
            task.Execute();

            // At this point the date string should be today's date, and the revision should be 0.
            wrapper = new AssemblyInfoWrapper(task.AssemblyInfoFile[0].ItemSpec);

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyBuildNumberFormat), version.BuildNumber, "The AssemblyBuildNumber auto-increment failed");
            Assert.AreEqual("0", version.Revision, "The AssemblyRevision auto-increment failed");

            version = new Microsoft.Build.Tasks.Version(wrapper["AssemblyFileVersion"]);
            Assert.AreEqual(DateTime.Now.ToString(task.AssemblyFileBuildNumberFormat), version.BuildNumber, "The AssemblyFileBuildNumber auto-increment failed");
            Assert.AreEqual("0", version.Revision, "The AssemblyFileRevision auto-increment failed");
        }
        #endregion

        #region Output Tests
        [TestMethod]
        public void OutputAssemblyVersionCSharp()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.cs";
            this.OutputAssemblyVersionTest(this.task);
        }

        [TestMethod]
        public void OutputAssemblyVersionVB()
        {
            this.task.AssemblyInfoFile[0].ItemSpec = @"AssemblyInfo.vb";
            this.OutputAssemblyVersionTest(this.task);
        }

        private void OutputAssemblyVersionTest(AssemblyInfo task)
        {
            task.AssemblyBuildNumberType = "AutoIncrement";
            task.AssemblyRevisionType = "AutoIncrement";

            task.AssemblyFileBuildNumberType = "AutoIncrement";
            task.AssemblyFileRevisionType = "AutoIncrement";

            task.Execute();

            Assert.AreEqual("1.0.1.1", task.MaxAssemblyVersion, "The final assembly version is incorrect.");
            Assert.AreEqual("1.0.1.1", task.MaxAssemblyFileVersion, "The final assembly version is incorrect.");
        }
        #endregion

        #region Helper Tests
        [TestMethod]
        public void MaxVersion()
        {
            string maxVersion = "0.0.0.0";

            this.task.UpdateMaxVersion(ref maxVersion, "1.0.0.0");
            Assert.AreEqual("1.0.0.0", maxVersion);

            this.task.UpdateMaxVersion(ref maxVersion, "1.0.051007.01");
            Assert.AreEqual("1.0.051007.01", maxVersion);

            this.task.UpdateMaxVersion(ref maxVersion, "1.0.051007.00");
            Assert.AreEqual("1.0.051007.01", maxVersion);
        }
        #endregion
    }
}
